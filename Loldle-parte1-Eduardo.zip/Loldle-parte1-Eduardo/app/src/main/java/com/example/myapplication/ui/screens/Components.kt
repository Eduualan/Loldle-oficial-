package com.example.myapplication.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.*
import coil3.compose.*
import com.example.myapplication.data.local.ChampionEntity

// Cores e componentes compartilhados pelas duas partes do app.
internal val ink = Color(0xFF101820)
internal val gold = Color(0xFFC8AA6E)
internal val panel = Color(0xFF1E2833)

@Composable
internal fun ChampionPortrait(champion: ChampionEntity, version: String?, size: Int) {
    val shape = RoundedCornerShape(10.dp)
    var imageFailed by remember(champion.id, version) { mutableStateOf(false) }
    Box(
        modifier = Modifier.size(size.dp).clip(shape),
        contentAlignment = Alignment.Center
    ) {
        Surface(modifier = Modifier.fillMaxSize(), shape = shape, color = Color(0xFF303B46)) { }
        if (version != null && !imageFailed) {
            AsyncImage(
                model = "https://ddragon.leagueoflegends.com/cdn/$version/img/champion/${champion.id}.png",
                contentDescription = "Retrato de ${champion.name}",
                contentScale = ContentScale.Crop,
                onError = { imageFailed = true }
            )
        } else {
            Text(champion.name.take(1).uppercase(), color = gold, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
internal fun Page(title: String, subtitle: String = "", content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, color = gold, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        if (subtitle.isNotBlank()) Text(subtitle, color = Color.LightGray)
        Spacer(Modifier.height(2.dp))
        content()
    }
}

@Composable
internal fun Field(label: String, value: String, enabled: Boolean = true, secret: Boolean = false, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        modifier = Modifier.fillMaxWidth(), enabled = enabled, singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None
    )
}
