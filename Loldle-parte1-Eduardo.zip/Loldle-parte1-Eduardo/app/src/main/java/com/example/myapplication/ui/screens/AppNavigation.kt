package com.example.myapplication.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.unit.*
import androidx.navigation.*
import androidx.navigation.compose.*
import com.example.myapplication.ui.viewmodel.AdminViewModel
import com.example.myapplication.ui.viewmodel.GameViewModel
import com.example.myapplication.ui.viewmodel.SessionViewModel

@Composable
fun AppNavigation(session: SessionViewModel, game: GameViewModel, admin: AdminViewModel) {
    val nav = rememberNavController()
    val role = session.role
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route.orEmpty()
    val mainRoutes = listOf("home", "game", "champions", "ranking")
    Scaffold(
        containerColor = ink,
        topBar = {
            if (route !in mainRoutes && route != "login") {
                Row(Modifier.fillMaxWidth().background(ink).padding(horizontal = 12.dp, vertical = 4.dp)) {
                    TextButton(onClick = {
                        nav.navigate("home") {
                            popUpTo("home") { inclusive = false }
                            launchSingleTop = true
                        }
                    }) { Text("← Início", color = gold) }
                }
            }
        },
        bottomBar = {
            if (route in mainRoutes) NavigationBar(containerColor = panel) {
                listOf("home" to "Início", "game" to "Jogar", "champions" to "Campeões", "ranking" to "Ranking").forEach { (destination, label) ->
                    NavigationBarItem(
                        selected = route == destination,
                        onClick = { nav.navigate(destination) { launchSingleTop = true } },
                        icon = { Text(label.take(1), color = gold) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(navController = nav, startDestination = "login", modifier = Modifier.padding(padding)) {
            composable("login") {
                LoginScreen(
                    onPlayer = { name -> session.loginPlayer(); game.setPlayer(name); nav.navigate("home") { popUpTo("login") { inclusive = true } } },
                    onAdmin = { pin -> if (session.loginAdmin(pin)) { nav.navigate("home") { popUpTo("login") { inclusive = true } }; true } else false }
                )
            }
            composable("home") {
                HomeScreen(role, onGame = { nav.navigate("game") }, onHistory = { nav.navigate("history") }, onAdmin = { nav.navigate("admin") })
            }
            composable("game") { GameScreen(game) }
            composable("champions") { ChampionListScreen(admin) { nav.navigate("detail/${it.id}") } }
            composable("detail/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { back ->
                ChampionDetailScreen(admin.state.champions.firstOrNull { it.id == back.arguments?.getString("id") }, admin.state.championVersion)
            }
            composable("ranking") { RankingScreen(admin) }
            composable("history") {
                HistoryScreen(
                    admin = admin,
                    canManage = role == "ADMIN",
                    onEdit = { nav.navigate("gameEdit/${it.id}") },
                    onDelete = admin::deleteGame
                )
            }
            composable("gameEdit/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { back ->
                val gameId = back.arguments?.getLong("id")
                val record = admin.state.games.firstOrNull { it.id == gameId }
                if (role == "ADMIN" && record != null) {
                    GameRecordFormScreen(record, admin) { nav.popBackStack() }
                } else {
                    Page("Partida não encontrada", "Entre como administrador para editar o histórico.") { }
                }
            }
            composable("admin") {
                if (role == "ADMIN") AdminScreen(admin, onEdit = { nav.navigate("edit/${it ?: "new"}") }, onHistory = { nav.navigate("history") })
                else HomeScreen(role, onGame = { nav.navigate("game") }, onHistory = { nav.navigate("history") }, onAdmin = { nav.navigate("login") })
            }
            composable("edit/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { back ->
                if (role == "ADMIN") {
                    val id = back.arguments?.getString("id")
                    ChampionFormScreen(admin.state.champions.firstOrNull { it.id == id }, admin) { nav.popBackStack() }
                } else {
                    LaunchedEffect(role) { nav.navigate("home") { popUpTo("edit/{id}") { inclusive = true } } }
                    Page("Acesso restrito", "Entre como administrador para continuar.") { }
                }
            }
        }
    }
}
