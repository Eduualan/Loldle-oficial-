package com.example.myapplication.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.unit.*
import com.example.myapplication.ui.viewmodel.AdminViewModel
import com.example.myapplication.ui.viewmodel.GameViewModel
import com.example.myapplication.ui.viewmodel.GuessResult

// PARTE 1 - Jogo: login, início, partida, dicas e ranking.

@Composable
internal fun LoginScreen(onPlayer: (String) -> Unit, onAdmin: (String) -> Boolean) {
    var name by rememberSaveable { mutableStateOf("") }
    var pin by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf("") }
    Page("LOLDLE", "Entre para jogar") {
        Field("Seu nome", name) { name = it }
        Button(onClick = { onPlayer(name) }, modifier = Modifier.fillMaxWidth()) { Text("Entrar como jogador") }
        HorizontalDivider(color = gold)
        Field("PIN do administrador (demo: 1234)", pin, secret = true) { pin = it }
        Button(onClick = { if (!onAdmin(pin)) error = "PIN incorreto." }, modifier = Modifier.fillMaxWidth()) { Text("Entrar como administrador") }
        if (error.isNotEmpty()) Text(error, color = Color(0xFFFF8A80))
    }
}

@Composable
internal fun HomeScreen(role: String, onGame: () -> Unit, onHistory: () -> Unit, onAdmin: () -> Unit) {
    Page("LOLDLE", if (role == "ADMIN") "Painel de administração" else "Descubra o campeão do dia") {
        Text("Compare classe, recurso e alcance dos seus palpites.", color = Color.LightGray)
        Button(onClick = onGame, modifier = Modifier.fillMaxWidth()) { Text("Começar partida") }
        Button(onClick = onHistory, modifier = Modifier.fillMaxWidth()) { Text("Ver histórico") }
        if (role == "ADMIN") Button(onClick = onAdmin, modifier = Modifier.fillMaxWidth()) { Text("Gerenciar campeões") }
        Text("Os campeões são carregados da API Data Dragon e guardados no aparelho.", color = Color.LightGray)
    }
}

@Composable
internal fun GameScreen(game: GameViewModel) {
    val state = game.state
    val suggestions = game.suggestions()
    Page("Partida", state.message) {
        Text("Tentativas: ${state.guesses.size}/6", color = gold, fontWeight = FontWeight.Bold)
        Field("Nome do campeão", state.guess, enabled = !state.finished, onChange = game::updateGuess)
        if (suggestions.isNotEmpty()) suggestions.forEach { champion ->
            Card(
                Modifier.fillMaxWidth().clickable { game.updateGuess(champion.name) },
                colors = CardDefaults.cardColors(containerColor = panel)
            ) {
                Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    ChampionPortrait(champion, state.championVersion, 48)
                    Column {
                        Text(champion.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(champion.role, color = Color.LightGray, fontSize = 12.sp)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = game::submitGuess, enabled = !state.finished) { Text("Tentar") }
            Button(onClick = game::restart) { Text("Nova partida") }
        }
        state.error?.let { Text(it, color = Color(0xFFFF8A80)) }
        state.guesses.reversed().forEach { GuessCard(it, state.championVersion) }
    }
}

@Composable
internal fun GuessCard(result: GuessResult, version: String?) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = panel)) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            ChampionPortrait(result.champion, version, 64)
            Column {
                Text(result.champion.name, color = gold, fontWeight = FontWeight.Bold)
                Hint("Classe", result.champion.role, result.sameRole)
                Hint("Gênero", result.champion.gender, result.sameGender)
                Hint("Raça", result.champion.species, result.sameSpecies)
                Hint("Recurso", result.champion.resource, result.sameResource)
                Hint("Alcance", result.champion.rangeType, result.sameRange)
            }
        }
    }
}

@Composable
internal fun Hint(label: String, value: String, matches: Boolean) {
    Text("$label: $value ${if (matches) "✓" else "✗"}", color = if (matches) Color(0xFF8BD3A8) else Color.LightGray)
}

@Composable
internal fun RankingScreen(admin: AdminViewModel) {
    val ranking = admin.ranking()
    Page("Ranking", "Vitórias registradas neste aparelho") {
        if (ranking.isEmpty()) Text("Ainda não há vitórias salvas.", color = Color.LightGray)
        ranking.forEachIndexed { index, (player, wins) ->
            Text("${index + 1}. $player — $wins vitória(s)", color = Color.White, modifier = Modifier.padding(8.dp))
        }
    }
}
